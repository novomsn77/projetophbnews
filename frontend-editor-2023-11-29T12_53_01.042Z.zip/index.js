function mudarCorDeFundo(){

  var elemenoAlvo = document.getElementById('elemento-alvo');
  var cores = ['#1C1C1C', '#00008B', '#008B8B', '#32CD32', '#A0522D'];
  var corAtual  = elemenoAlvo.style.backgroundColor; 

    var novaCor  = {cores}; 
    var novaCor = cores[Math.floor(Math.random()* cores.length)];
    while ( novaCor == corAtual){
      novaCor = cores[Math.floor(Math.random() * cores.lenght)];
    }
    elemenoAlvo.style.backgroundColor = novaCor;

  function CorTextoNova(){
  var texto = document.getElementById('texto');
  var coresTxt = ['#ffffff','#1C1C1C','#32CD32', '#008B8B', '#A0522D'];
  var novaCorTexto = body.style.color;
  var novaCorTexto = {coresTxt};

  var novaCorTexto = cores[Math.floor(Math.random()* coresTxt.length)];
  

    }
}