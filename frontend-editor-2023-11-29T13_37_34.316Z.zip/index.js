function mudarCorDeFundo(){
  var elemenoAlvo = document.getElementById('elemento-alvo');
  var cores = ['#1C1C1C', '#00008B', '#008B8B', '#32CD32', '#A0522D'];
  var corAtual  = elemenoAlvo.style.backgroundColor; 
    var novaCor  = {cores}; 
    var novaCor = cores[Math.floor(Math.random()* cores.length)];
    while ( novaCor == corAtual){
      novaCor = cores[Math.floor(Math.random() * cores.lenght)];
    }
    elemenoAlvo.style.backgroundColor = novaCor;
    var texto = document.getElementById('texto');
  var coresTxt = ['#008B8B','#1C1C1C', '#32CD32', '#00008B', '#A0522D'];
  var novaCorTexto = texto.style.color;

  var novaCorTexto = {coresTxt}; 
  var novaCorTexto = coresTxt[Math.floor(Math.random()* coresTxt.length)];
   while ( novaCorTexto == coresTxt){
      novaCorTexto = coresTxt[Math.floor(Math.random() * coresTxt.lenght)];
    }
    texto.style.color = novaCorTexto;
    };

